use ratingsaggregator 
DELETE 
FROM players 
WHERE name 
LIKE '%name%';