<?php

// (override) set local environment for testing purposes
return [
    'default' => 'mysql_test'
];
