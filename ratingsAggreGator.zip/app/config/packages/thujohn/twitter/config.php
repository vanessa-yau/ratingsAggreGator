<?php

// You can find the keys here : https://dev.twitter.com/

return array(
	'API_URL'             => 'api.twitter.com',
	'API_VERSION'         => '1.1',
	'AUTHENTICATE_URL'    => 'https://api.twitter.com/oauth/authenticate',
	'AUTHORIZE_URL'       => 'https://api.twitter.com/oauth/authorize',
	'ACCESS_TOKEN_URL'    => 'oauth/access_token',
	'REQUEST_TOKEN_URL'   => 'oauth/request_token',
	'USE_SSL'             => true,

	'CONSUMER_KEY'        => '8iQBLVmS7bofjtSUeV5gGQg1k',
	'CONSUMER_SECRET'     => 's8QMkVbczSgkfbOV4Re5eGrYGgWPE8DBm1dpo4AaIllucflxyw',
	'ACCESS_TOKEN'        => '2893192415-ZsqwNwRYpIQevgH8Tt01G1Cv0HiVGK4p8gcZBQN',
	'ACCESS_TOKEN_SECRET' => 'S5OEYZ1ENNIUfQVYzh9zK0uYnFF3Pc79DAlvrPYud8Xrr',
);
